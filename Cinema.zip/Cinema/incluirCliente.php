<?php
    include "controle.php";
    include "conexao.php";

    if(isset($_POST['nome'])){ //Entrada de erro

    $nome = trim($_POST['nome']);
    $usuario = trim($_POST['usuario']);
    $senha = trim($_POST['senha']);
    $email = trim($_POST['email']);
    $datanasc = trim($_POST['datanasc']);
    $telefone = trim($_POST['telefone']);

    $sql = "insert into clientes(nome,usuario,senha,email,datansc,telefone) values 
    ('$nome','$usuario','$senha','$email','$datanasc','$telefone')";
    $incluir = mysqli_query($conexao,$sql);

            if($incluir){
                echo 
                "<script>
                alert('Cadastro realizado com sucesso')
                window.location = 'index.php';
                </script>";
            } 
            else {
                echo "<b><p> Site temporariamente em manutenção, volte mais tarde</p>
                        <p>Entre em contato com o administrador do sistema</p></b>";
                        
                        echo mysqli_error($conexao);
    }
    }
     else {
        echo "<b><p> Esta é uma página de tratamento de dados, o site está temporariamente em manutenção, volte mais tarde. </p>
        <p>Clique<a href='index.php'> aqui  </a> para voltar para página inicial.</p></b>";
    }
    include "footer.php";