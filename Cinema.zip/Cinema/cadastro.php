<?php
  include "controle.php"
?>
<b><h1>CINE+</h1></b>
<div class="container bg-dark pag">    
            
<form name="form" method="post" action="incluirCliente.php" class="container bg-dark">
  <div class=" form-group">
  
    <div class="mb-3 col-sx-3">
      <label for="nome" class="form-label" name="nome" required ></label>
      <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome" style="color: black;" required>
    </div>

    <div class="mb-3">
      <label for="usuario" class="form-label" name="usuario" required></label>
      <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Usuario" required>
    </div>

    <div class="mb-3">
      <label for="senha" class="form-label" name="senha" required></label>
      <input type="password" class="form-control" id="senha" name="senha" placeholder="Senha" required>
    </div>

    <div class="mb-3">
      <label for="email" class="form-label" name="email" required></label>
      <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
    </div>

    <div class="mb-3">
      <label for="datanasc" class="form-label" name="datanasc" required></label>
      <input type="text" class="form-control" id="datanasc" name="datanasc" placeholder="Data de nascimento" required>
    </div>

    <div class="mb-3">
      <label for="telefone" class="form-label" name="telefone" required></label>
      <input type="text" class="form-control" id="telefone" name="telefone" placeholder="Telefone" required>
    </div>

    <div class="mb-3 form-check">
      <input type="checkbox" class="form-check-input" id="exampleCheck1">
      <label class="form-check-label " for="exampleCheck1" style="color: white;">Lembre-se de mim</label>
    </div>

    <button type="submit" class="btn btn-primary">Enviar cadastro</button>
  </div>
</form>


<?php
  include "footer.php"
?>