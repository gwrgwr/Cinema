<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cine+</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="css/phpcss.css">
  </head>
  <body style="background-image: url(imagens/Cinema-IMAX.jpg)">
        <div class="container-fluid bg-dark p-3"> 
            <div class="row">
                <div class="col text-start">
                  <a href="index.php">
                    <img src="imagens/Ciné+_logo_2011.png" width="50" height="50" alt="">
                  </a> 
                </div>
            </div>                                              
        </div> 
  </body>
</html>