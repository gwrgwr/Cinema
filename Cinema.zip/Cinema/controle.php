<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cine+</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="css/phpcss.css">
  </head>
  <body style="background-color:black; background-image: url(imagens/Cinema-IMAX.jpg);">
        <div class="container-fluid bg-dark"> 
            <div class="row">
            <nav class="navbar navbar-expand-lg " style="background-color: #4F4F4F;">
            <a href="index.php">
                  <img src="imagens/YagoCineArtboard.png" alt="Cine+" width="150" height="130">
            </a>   
        <div class="container">
          
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul  class="navbar-nav navbar-dark me-auto mb-2 mb-lg-0">
              <li  class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="programacao.html">Programação</a></b>
              </li>
              <li  class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="plusbar.html">Plus Bar</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="alugue.html">Alugue</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="fidelidade.html">Fidelidade</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="localizacao.html">Localização</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="login.php">Login</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="cadastro.php">Cadastro</a></b>
              </li>  
              </ul>
              <div class=" input-sm mb-3">
                <input type="text" class="form-control" placeholder="Procurar por filme" aria-label="Recipient's username" aria-describedby="basic-addon2">
                <div class="input-group-append">
                  <button class="container btn btn-outline-secondary" type="button">Procurar</button>
                </div>
              </div>
          </div>
        </div>
      </nav>
                
            </div>                                              
        </div> 
  </body>
</html>