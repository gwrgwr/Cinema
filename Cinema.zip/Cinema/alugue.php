<?php
include "controle.php"
?>


<?php
include "footer.php"
?>