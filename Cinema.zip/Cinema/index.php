<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cine+</title>
    <link rel="stylesheet" href="css/phpcss.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  </head>
  <body background="imagens/Cinema-IMAX.jpg" id="imagem-de-fundo" style="height: 100%;; background-repeat: no-repeat; background-size: cover;">

    
    <nav class="navbar navbar-expand-lg " style="background-color: #4F4F4F;">
            <a href="index.html">
                  <img src="imagens/Ciné+_logo_2011.png" alt="Cine+" width="50" height="40">
            </a>   
        <div class="container">
          
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul  class="navbar-nav navbar-dark me-auto mb-2 mb-lg-0">
              <li  class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="programacao.html">Programação</a></b>
              </li>
              <li  class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="plusbar.html">Plus Bar</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="alugue.html">Alugue</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="fidelidade.html">Fidelidade</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="localizacao.html">Localização</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="login.php">Login</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="cadastro.php">Cadastro</a></b>
              </li>
              <li>
              <div class="container">
                <a class="navbar-brand" href="#">
                  <img src="imagens/libra-imagem.png" alt="Libras" width="50" height="64">
                </a>
              </li>   
              </ul>
              <div class=" input-sm mb-3">
                <input type="text" class="form-control" placeholder="Procurar por filme" aria-label="Recipient's username" aria-describedby="basic-addon2">
                <div class="input-group-append">
                  <button class="container btn btn-outline-secondary" type="button">Procurar</button>
                </div>
              </div>
          </div>
        </div>
      </nav>
      <div vw class="enabled">
        <div vw-access-button class="active"></div>
        <div vw-plugin-wrapper>
          <div class="vw-plugin-top-wrapper"></div>
        </div>
      </div>
      <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
      <script>
        new window.VLibras.Widget('https://vlibras.gov.br/app');
      </script>
        
      <section>

        <img id="bradesco" class="parceiros" src="imagens/Bradesco.png" alt="Bradesco">
        <img id="bradesco-prime" class="parceiros" src="imagens/Bradesco-prime.png" alt="Bradesco prime">
        <img id="vivo" class="parceiros" src="imagens/Vivo.png" alt="Vivo">
        <img id="elo" class="parceiros" src="imagens/ELO.png" alt="Elo">
        <img id="pringles" class="parceiros" src="imagens/pringles.png" alt="Pringles">

        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
          <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="3" aria-label="Slide 4"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="4" aria-label="Slide 5"></button>
          </div>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img  src="imagens/carousel-wakanda.png" class="d-block w-100 col-12 md-8 mb-6 carrosel" alt="...">
            </div>
            <div class="carousel-item">
              <img src="imagens/carousel-pele.png" class="d-block w-100 carrosel" alt="...">
            </div>
            <div class="carousel-item">
              <img src="imagens/carousel-cidadededeus.png" class="d-block w-100 carrosel" alt="...">
            </div>
            <div class="carousel-item">
              <img src="imagens/carousel-cidadedoshomens.png" class="d-block w-100 carrosel" alt="...">
            </div>
            <div class="carousel-item">
              <img src="imagens/carousel-tropadeelite.png" class="d-block w-100 carrosel" alt="...">
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
























      </section>
















    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
  </body>
</html>