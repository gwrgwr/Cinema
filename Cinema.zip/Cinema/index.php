<?php
include "controle.php"
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cine+</title>
    <link rel="stylesheet" href="css/phpcss.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  </head>
  <body background="imagens/Cinema-IMAX.jpg" id="imagem-de-fundo" style="height: 100%;; background-repeat: no-repeat; background-size: cover;">

    
    
      <div vw class="enabled">
        <div vw-access-button class="active"></div>
        <div vw-plugin-wrapper>
          <div class="vw-plugin-top-wrapper"></div>
        </div>
      </div>
      <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
      <script>
        new window.VLibras.Widget('https://vlibras.gov.br/app');
      </script>
        
      <section>

        <div id="carouselExampleIndicators" class="carousel slide position-relative bottom-0 start-50 translate-middle-x" data-bs-ride="true">
          <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="3" aria-label="Slide 4"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="4" aria-label="Slide 5"></button>
          </div>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img  src="imagens/foisgo.jpg" class="d-block w-100 col-12 md-8 mb-6 carrosel" alt="...">
            </div>
            <div class="carousel-item">
              <img src="imagens/tintin.jpg" class="d-block w-100 carrosel" alt="...">
            </div>
            <div class="carousel-item">
              <img src="imagens/mortalcombao.jpg" class="d-block w-100 carrosel" alt="...">
            </div>
            <div class="carousel-item">
              <img src="imagens/wondemule.png" class="d-block w-100 carrosel" alt="...">
            </div>
            <div class="carousel-item">
              <img src="imagens/incepcao.jpg" class="d-block w-100 carrosel" alt="...">
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
        <img id="bradesco" class="parceiros" src="imagens/Bradesco.png" alt="Bradesco">
        <img id="bradesco-prime" class="parceiros" src="imagens/Bradesco-prime.png" alt="Bradesco prime">
        <img id="vivo" class="parceiros" src="imagens/Vivo.png" alt="Vivo">
        <img id="elo" class="parceiros" src="imagens/ELO.png" alt="Elo">
        <img id="pringles" class="parceiros" src="imagens/pringles.png" alt="Pringles">
        <img id="badest" class="badest" src="imagens/badest.png" alt="Bradesco Banner">
        























      </section>
















    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
  </body>
</html>
<?php
include "footer.php";
?>