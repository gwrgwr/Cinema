<?php
    include "controle.php";
    include "segurancaAdm.php";
?>
        <div class="input-group mb-1 w-25 searchrecipient">
  <input type="text" class="form-control border border-0" placeholder="Procurar por filmes" aria-label="Recipient's username" aria-describedby="button-addon2">
  <button class="btn btn-secondary" type="button" id="button-addon2"><img id="searchicon" src="imagens/searchicon.png" alt=""></button>
</div>
    <div class="input-group mb-1 w-25  filesinput">
    <form name="form" method="post" action="incluirFilme.php" enctype="multipart/form-data">
  <input type="file" class="form-control" id="inputGroupFile02">
  <label class="input-group-text" for="inputGroupFile02" name="nome"></label>
  </form>
</div>






<?php
    include "footer.php";
?>