<?php
include "conexao.php";
include "controle.php";

if(isset($_GET['nome'])){
    $nome = $_GET['nome'];
    $sql = "select * from filmes where nome = '$nome'";
    $seleciona = mysqli_query($conexao,$sql);
    $exibe =  mysqli_fetch_array($seleciona);
    }
 ?>
    <div class="container pag">
    <h1>Alterar foto</h1>
 <hr>
    <div class="row">
        <div class="col-2"></div>
     <div class="col-8"></div>
     <form name="form" method="post" action="updateFoto.php" 
     enctype="multipart/form-data">

 <input type="file" id="foto" name="foto">
 <div class="row mt-5">
    <div class=" col text-start mt-5">
        <button type="submit " class="btn btn-warning btn-sm mt-5"onclick="window.history.go(-1)">
        Voltar
    </div>
 </div>
 <div class="col text-end mt-5">
    <button type="sybmit" class="btn btn-primary btn sm botao">Enviar foto</button> 
 </div>
 </div>
 </button>
    </form>
         </div>
           </div>