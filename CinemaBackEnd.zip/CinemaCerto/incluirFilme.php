<?php

include "conexao.php";

if(isset($_POST['nome'])){
    //entrada - coletar os dados do formulário
    $nome = trim($_POST['nome']);
    $fxeta = trim($_POST['fxeta']);
    
    $foto = 'imagens/semfoto.png';
    
    //processamento - incluir no banco de dados
    $sql = "insert into 
     filmes(nome,fxeta)
     values('$nome','$fxeta')";
     $incluir = mysqli_query($conexao,$sql);

    //saida - feedback ao usuário
    if($incluir){
        echo "
            <script>
                alert('Usuário cadastrado com sucesso!');
                window.location = 'listarFilmes.php';
            </script>
        ";
    }
    else{
        echo "
            <p> Sistema temporariamente fora do ar. Tente novamente mais tarde. </p>
            <p> Entre em contato com o administrador do Sistema. </p>
        ";
        echo mysqli_error($conexao);
    }
}
else{
    echo "
    <p> Esta é uma página de tratamento de dados. </p>
    <p> Clique <a href='formularioUsuario.php'>aqui</a> para incluir um Usuário. </p>
";  
}
include "../footer.php"

?>