<?php
    include "conexao.php";
    include "controle.php";

    if(isset($_GET['id'])){

        $id = $_GET['id'];
        
        $sql = "select * from filmes where id = '$id'";
        $seleciona = mysqli_query($conexao,$sql);
        $exibe = mysqli_fetch_array($seleciona);

        $nome = $exibe['nome'];
        $fxeta = $exibe['fxeta'];
    
?>

        <div class="container pag">    
            <h1>Editar Dados do Filme</h1>
            <hr>
            <form name="form" method="post" action="updateFilme.php">
                <div class="mb-3">
                    <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">                    
                </div>                
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome</label>
                    <input type="text" class="form-control" id="nome" name="nome" value="<?php echo $nome; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="fxeta" class="form-label">Faixa etária</label>
                    <input type="fxeta" class="form-control" id="fxeta" name="fxeta" value="<?php echo $fxeta; ?>"  required>
                </div>
                
                <div class="row mt-5">
                    <div class="col text-start">
                        <a href="listarFilmes.php"> <button type="button" class="btn btn-warning btn-sm">Voltar</button> </a>
                    </div>
                    
                    <div class="col text-end">
                        <button type="submit" class="btn btn-primary btn-sm botao">Alterar dados</button></a>
                    </div>
                </div>
            </form>           
        </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
<?php

    }
    else{
        echo "
            <p> Esta é uma página de tratamento de dados. </p>
            <p> Clique <a href='listarFilmes.php'>aqui</a> para selecionar um Usuário. </p>
        ";   
    }

    include "footer.php";
?>