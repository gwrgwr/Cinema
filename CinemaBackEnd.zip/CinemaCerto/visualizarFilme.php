<?php
    include "conexao.php";
    include "controle.php";

    if(isset($_GET['id'])){

        $id = $_GET['id'];
        
        $sql = "select * from filmes where id = '$id'";
        $seleciona = mysqli_query($conexao,$sql);
        $exibe = mysqli_fetch_array($seleciona);

        $nome = $exibe['nome'];
        $fxeta = $exibe['fxeta'];
        $foto = $exibe['foto'];

    
?>
    <div class="container pag">
        <div class="text-end">
            <a href="listarFilmes.php"> <button type="button" class="btn btn-success btn-sm">Listar filmes</button> </a>
        </div>
        <h2>Usuário: <?php echo $nome; ?></h2>
        <hr>
        <div class="container text-start bg-gradient p-3">
            <div class="row">
                <div class="col-2 text-center">
                    <img src="<?php echo $foto?>">
                    <p> <a href="editarFoto.php?nome=<?php echo $nome; ?>">Editar Foto </a></p>
                </div>
                <div class="col-10">
                    <?php
                        echo "
                            <p> nome: $nome </p>
                            <p> fxeta: $fxeta </p>                    
                                                                   
                        ";
                    ?>  
                </div>
            </div>                
                     
        </div>
        <div class="row">
            <div class="col text-start">
                <a href="listarFilmes.php"> <button type="button" class="btn btn-warning btn-sm">Voltar</button> </a>
            </div>

            
             
            <div class="col text-end">
                <a href="editarFilmes.php?nome=<?php echo $nome ?>"><button type="button" class="btn btn-light btn-sm botao">Editar dados do filme</button></a>
            </div>
        </div>
    </div>   

<?php

    }
    else{
        echo "
            <p> Esta é uma página de tratamento de dados. </p>
            <p> Clique <a href='listarFilmes.php'>aqui</a> para selecionar um Usuário. </p>
        ";   
    }
?>

<?php
    include "footer.php";
?>