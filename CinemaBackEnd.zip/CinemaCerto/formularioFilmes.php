<?php
    include "controle.php";
?>
        <div class="container pag w-75">    
            <h1>Cadastro de filmes</h1>
            <form name="form" method="post" action="incluirFilme.php">
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome</label>
                    <input type="text" class="form-control" id="nome" name="nome" required>
                </div>
                <div class="mb-3">
                    <label for="fxeta" class="form-label">fxeta</label>
                    <input type="text" class="form-control" id="fxeta" name="fxeta" required>
                </div>     
                <div class="row">
                    <div class="col text-start">
                        <a href="listarFilmes.php"> <button type="button" class="btn btn-warning btn-sm">LISTAR USUÁRIOS</button> </a>
                    </div>
                    <div class="col text-end">
                        <button type="submit" class="btn btn-primary btn-sm botao">CADASTRAR</button></a>
                    </div>
                </div>
            </form>           
        </div>

<?php
    include "footer.php";
?>