<?php
    include "conexao.php";
    include "controle.php";
    
    
    $sql = "select * from filmes order by nome";
    $seleciona = mysqli_query($conexao,$sql);
    
?>

        <div class="container  pag">
            <div class="text-end">
                <a href="formularioFilmes.php"> <button type="button" class="btn btn-success btn-sm">Novo cadastro de filme</button> </a>
            </div>
            <h2>Lista de Filmes</h2>
            <div class="container text-center">
                <div class="row bg-dark text-light espaco">
                    <div class="col-3">
                        Foto
                    </div>
                    <div class="col-3">
                        Nome
                    </div>
                    <div class="col-3">
                        Faixa etária
                    </div>
                    <div class="col-3">
                        CONTROLE
                    </div>
                </div>
                <?php                     
                    while ($exibe = mysqli_fetch_array($seleciona)){
                        $nome = $exibe['nome'];                        
                        $id = $exibe['id'];                        
                ?>
                <div class="row bg-gradient espaco">
                    <div class="col-3">
                        <img src='<?php echo $exibe['foto']?>' class="foto">
                    </div>
                    <div class="col-3">
                        <?php echo $exibe['nome']?>
                    </div>
                    
                    <div class="col-3">
                        <?php echo $exibe['fxeta']?>
                    </div>
                    <div class="col-3">
                        <a href="visualizarFilme.php?id=<?php echo $id ?>"><button type="button" class="btn btn-success btn-sm botao">Visualizar</button></a>
                        <a href="editarFilme.php?id=<?php echo $id ?>"><button type="button" class="btn btn-primary btn-sm botao">Editar</button></a>
                        <a href="excluirFilme.php?id=<?php echo $id ?>" onclick="return confirm('Confirma a Exclusão do Usuário?')" > <button type="button" class="btn btn-danger btn-sm">Excluir</button> </a>
                    </div>
                </div>
                <?php
                    }
                ?>
            </div>
        </div>  

<?php
    include "footer.php";
?>
   