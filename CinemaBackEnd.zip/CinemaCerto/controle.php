<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cine+</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="css/phpcss.css">
  </head>
  <body style="background-color:black; background-image: url(imagens/Cinema-IMAX.jpg);">
        <div class="container-fluid bg-dark"> 
            <div class="row">
            <nav class="navbar navbar-expand-lg " style="background-color: #4F4F4F;">
            <a href="index.php">
                  <img src="imagens/YagoCineArtboard.png" alt="Cine+" width="150" height="130">
            </a>   
        <div class="barra container">
          
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul  class="navbar-nav navbar-dark me-auto mb-2 mb-lg-0">
              <li  class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="programacao.php">Programação</a></b>
              </li>
              <li  class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="plusbar.php">Plus Bar</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="alugue.php">Alugue</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="fidelidade.php">Fidelidade</a></b>
              </li>
              <li class="nav-item p-3">
                <b><a class="nav-link active" aria-current="page" href="localizacao.php">Localização</a></b>
              </li>
                
              <div class=" nav-item p-3 login">
                        <?php
                                  if (!isset($_SESSION)){
                                      session_start();
                                  }
                                  if(isset($_SESSION['usuario'])){
                                      $usuario = $_SESSION['usuario'];
                                      $nivel = $_SESSION['nivel'];
                                      
        
                                      echo  " <b><p  style='color: white; display: inline-block'>Bem-vindo, $usuario  | <a href='logout.php'> Logout </a></p></b>";
                                  }
                                  else{
                                      echo " 
                                          <a href='login.php'> Login </a> |
                                          <a href='cadastro.php'> Não possuo Cadastro </a>
                                      ";  
                                  }
                              ?>
                        
                      </div>
              </ul>
              <div vw class="enabled">
        <div vw-access-button class="active"></div>
        <div vw-plugin-wrapper>
          <div class="vw-plugin-top-wrapper"></div>
        </div>
      </div>
      <script src="https://vlibras.gov.br/app/vlibras-plugin.js"></script>
      <script>
        new window.VLibras.Widget('https://vlibras.gov.br/app');
      </script>
              </div>
          </div>
        </div>
      </nav>
            </div>                                              
        </div> 
  </body>
</html>