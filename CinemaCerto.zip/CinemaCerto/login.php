<?php
    include "controle.php"
?>

<h1><b>CINE+</b></h1>
<div class="container bg-dark w-25 pag">
<form name="form" method="post" action="validarLogin.php" class="container bg-dark">
  <div class=" form-group">
  
  

    <div class="mb-3">
      <label for="usuario" class="form-label" name="usuario" required></label>
      <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Usuario" required>
    </div>

    <div class="mb-3">
      <label for="senha" class="form-label" name="senha" required></label>
      <input type="password" class="form-control" id="senha" name="senha" placeholder="Senha" required>
    </div>

   

    <div class="mb-3 form-check text-sm-start">
      <input type="checkbox" class="form-check-input" id="exampleCheck1">
      <label class="form-check-label " for="exampleCheck1" style="color: white; text-align: start;">Lembre-se de mim</label>
    </div>

    <button type="submit" class="btn btn-primary">Logar</button>
  </div>
</form>


<?php
  include "footer.php"
?>