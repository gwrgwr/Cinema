<?php
    include "controle.php";
    include "segurancaAdm.php";
?>
        <div class="input-group mb-1 w-25 searchrecipient">
  <input type="text" class="form-control border border-0" placeholder="Procurar por filmes" aria-label="Recipient's username" aria-describedby="button-addon2">
  <button class="btn btn-secondary" type="button" id="button-addon2"><img id="searchicon" src="imagens/searchicon.png" alt=""></button>
</div>
    <div class="mb-3 w-25">
         <label for="formFileMultiple" class="form-label">Multiple files input example</label>
         <input class="form-control" type="file" id="formFileMultiple" multiple>
    </div>





<?php
    include "footer.php";
?>