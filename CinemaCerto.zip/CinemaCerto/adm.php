<?php
    include "controle.php";
    include "segurancaAdm.php";
?>

<?php
    include "footer.php";
?>