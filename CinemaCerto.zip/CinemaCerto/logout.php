<?php
    session_start(); //inicia a sessão
    $_SESSION = array(); //carrega o array de dados
    session_destroy(); //destroi todas as sssões iniciadas
    header('location: index.php'); //redireciona para a area de login
?>