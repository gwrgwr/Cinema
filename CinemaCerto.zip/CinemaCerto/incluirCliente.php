<?php
    include "controle2.php";
    include "conexao.php";

    if(isset($_POST['nome'])){ //Entrada de erro

    $nome = trim($_POST['nome']);
    $usuario = trim($_POST['usuario']);
    $senha = trim($_POST['senha']);
    $email = trim($_POST['email']);
    $datanasc = trim($_POST['datanasc']);
    $telefone = trim($_POST['telefone']);
    $nivel = "cli";

    $sql = "insert into usuario(nome,usuario,senha,email,datanasc,telefone,nivel) values 
    ('$nome','$usuario','$senha','$email','$datanasc','$telefone','$nivel')";
    $incluir = mysqli_query($conexao,$sql);

            if($incluir){
               
                echo 
                "<script>
                alert('Cadastro realizado com sucesso')
           
                </script>";
                

                $sql = "select * from usuario where usuario ='$usuario' and senha = '$senha'";
                $testeLogin = mysqli_query($conexao,$sql);
                $existe = mysqli_num_rows($testeLogin);

                if($existe){
                    $dados = mysqli_fetch_array($testeLogin);
                    $usuario = $dados['usuario'];
                    $nivel = $dados['nivel'];
                    
                
                    if(!isset($_SESSION)){
                        session_start();
                    }
                    $_SESSION['usuario'] = $usuario;
                    $_SESSION['nivel'] = $nivel;
                

                    if ($nivel == 'adm'){
                        header('location: adm.php');
                    }
                    else{
                        header('location: index.php');
                    }
                } 
            }
            else {
                echo "<b><p> Site temporariamente em manutenção, volte mais tarde</p>
                        <p>Entre em contato com o administrador do sistema</p></b>";
                        
                        echo mysqli_error($conexao);
            }
        
    }
     else {
        echo "<b><p style='color: white';> Esta é uma página de tratamento de dados, o site está temporariamente em manutenção, volte mais tarde. </p>
        <p style='color: white';>Clique<a href='index.php'> aqui  </a> para voltar para página inicial.</p></b>";
    }
    