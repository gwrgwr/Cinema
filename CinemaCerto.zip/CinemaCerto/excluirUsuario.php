<?php
    include "conexao.php";
    include "controle2.php";
    

    if(isset($_GET['usuario'])){

        $usuario = $_GET['usuario'];
        
        $sql = "delete from usuario where usuarii = '$usuario'";
        $excluir = mysqli_query($conexao,$sql);

        //saida - feedback ao usuário
        if($excluir){
            echo "
                <script>
                    alert('Usuário exluido com Sucesso');
                    window.location = 'cadastro.php';
                </script>
            ";
            //header("location: listarAluno.php");
        }
        else{
            echo "
                <p style='color: white';> Bando de Dados temporariamente fora do ar. Tente novamente mais tarde. </p>
                <p style='color: white';> Entre em contato com o administrador do Site ... </p>
            ";
            echo mysqli_error($conexao);
        }
    }

    
?>